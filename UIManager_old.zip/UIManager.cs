﻿/*

TODO : 매핑UI 구현



*/


using System;
using System.Collections.Generic;
using System.Windows.Forms;

public class UIManager : Form
{
    private MappingManager mappingManager;
    private DeviceManager deviceManager;
    private MidiManager midiManager;
    private ComboBox controllerDropdown;
    private ComboBox midiDeviceDropdown;
    private Button toggleProcessingButton;
    private bool isProcessing = false;





    public UIManager(MappingManager mappingManager, DeviceManager deviceManager, MidiManager midiManager)
    {
        this.mappingManager = mappingManager;
        this.deviceManager = deviceManager;
        this.midiManager = midiManager;

        InitializeComponents();
    }

    private void InitializeComponents()
    {
        this.SuspendLayout();
        this.Text = "MIDI Mapping Manager";
        this.Width = 800;
        this.Height = 600;

        this.ResumeLayout(false);

        // 윈도우 설정



        // MIDI 처리 토글 버튼 추가
        toggleProcessingButton = new Button
        {
            Text = "Start Processing",
            Left = 300,
            Top = 200,
            Width = 200
        };

        toggleProcessingButton.Click += ToggleProcessingButton_Click;
        this.Controls.Add(toggleProcessingButton);

        // 매핑 로드 버튼
        Button loadMappingButton = new Button
        {
            Text = "Load Mapping",
            Left = 50,
            Top = 50,
            Width = 200
        };
        loadMappingButton.Click += LoadMappingButton_Click;
        this.Controls.Add(loadMappingButton);

        Button saveMappingButton = new Button
        {
            Text = "Save Mapping",
            Left = 50,
            Top = 100,
            Width = 200
        };
        saveMappingButton.Click += SaveMappingButton_Click;
        this.Controls.Add(saveMappingButton);

        Button printMappingButton = new Button
        {
            Text = "Print Mapping",
            Left = 50,
            Top = 150,
            Width = 200
        };
        printMappingButton.Click += PrintMappingButton_Click;
        this.Controls.Add(printMappingButton);


        // Label: 컨트롤러 선택
        Label controllerLabel = new Label
        {
            Text = "Select Controller:",
            Left = 50,
            Top = 50,
            Width = 200
        };
        this.Controls.Add(controllerLabel);

        // ComboBox: 컨트롤러 드롭다운
        controllerDropdown = new ComboBox
        {
            Left = 50,
            Top = 80,
            Width = 200,
            DropDownStyle = ComboBoxStyle.DropDownList // 읽기 전용 드롭다운
        };
        PopulateControllerDropdown();
        this.Controls.Add(controllerDropdown);

        // Button: 선택된 컨트롤러 출력
        Button selectControllerButton = new Button
        {
            Text = "Set Active Controller",
            Left = 50,
            Top = 120,
            Width = 200
        };
        selectControllerButton.Click += SelectControllerButton_Click;
        this.Controls.Add(selectControllerButton);


        // 윈도우 설정
        this.Text = "MIDI Mapping Manager";
        this.Width = 800;
        this.Height = 600;

        // MIDI 장치 선택
        Label midiDeviceLabel = new Label
        {
            Text = "Select MIDI Device:",
            Left = 300,
            Top = 50,
            Width = 200
        };
        this.Controls.Add(midiDeviceLabel);

        midiDeviceDropdown = new ComboBox
        {
            Left = 300,
            Top = 80,
            Width = 200,
            DropDownStyle = ComboBoxStyle.DropDownList
        };
        PopulateMidiDeviceDropdown();
        this.Controls.Add(midiDeviceDropdown);

        Button selectMidiDeviceButton = new Button
        {
            Text = "Set Active MIDI Device",
            Left = 300,
            Top = 120,
            Width = 200
        };
        selectMidiDeviceButton.Click += SelectMidiDeviceButton_Click;
        this.Controls.Add(selectMidiDeviceButton);



    }





    private void ToggleProcessingButton_Click(object sender, EventArgs e)
    {
        if (!isProcessing)
        {
            // Start Processing
            var activeController = deviceManager.GetActiveController(); // 활성 컨트롤러 가져오기
            if (activeController == IntPtr.Zero)
            {
                MessageBox.Show("No active controller selected!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            midiManager.StartProcessing(deviceManager.GetActiveController(), mappingManager);
            toggleProcessingButton.Text = "Stop Processing";
            isProcessing = true;
        }
        else
        {
            // Stop Processing
            midiManager.StopProcessing();
            toggleProcessingButton.Text = "Start Processing";
            isProcessing = false;
        }
    }

    private void LoadMappingButton_Click(object sender, EventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog
        {
            Filter = "JSON Files (*.json)|*.json",
            Title = "Load Mapping Profile"
        };

        if (openFileDialog.ShowDialog() == DialogResult.OK)
        {
            mappingManager.LoadMappingFromJson(openFileDialog.FileName);
            MessageBox.Show("Mapping loaded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    private void SaveMappingButton_Click(object sender, EventArgs e)
    {
        SaveFileDialog saveFileDialog = new SaveFileDialog
        {
            Filter = "JSON Files (*.json)|*.json",
            Title = "Save Mapping Profile"
        };

        if (saveFileDialog.ShowDialog() == DialogResult.OK)
        {
            mappingManager.SaveMappingToJson(saveFileDialog.FileName);
            MessageBox.Show("Mapping saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    private void PrintMappingButton_Click(object sender, EventArgs e)
    {
        mappingManager.PrintCurrentMapping();
    }

    private void PopulateControllerDropdown()
    {
        controllerDropdown.Items.Clear();

        var controllerNames = deviceManager.GetControllerNames();
        for (int i = 0; i < controllerNames.Count; i++)
        {
            controllerDropdown.Items.Add(new KeyValuePair<int, string>(i, controllerNames[i]));
        }

        controllerDropdown.DisplayMember = "Value";
        controllerDropdown.ValueMember = "Key";

        if (controllerDropdown.Items.Count > 0)
        {
            controllerDropdown.SelectedIndex = 0; // 첫 번째 항목 선택
        }
    }

    private void SelectControllerButton_Click(object sender, EventArgs e)
    {
        if (controllerDropdown.SelectedItem is KeyValuePair<int, string> selectedController)
        {
            int controllerIndex = selectedController.Key;
            deviceManager.SetActiveController(controllerIndex);
            IntPtr activeController = deviceManager.GetActiveController();

            if (activeController != IntPtr.Zero)
            {
                MessageBox.Show($"Controller {selectedController.Value} is now active.");
            }
            else
            {
                MessageBox.Show("Failed to activate the selected controller.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        else
        {
            MessageBox.Show("No controller selected!");
        }
    }

    private void PopulateMidiDeviceDropdown()
    {
        midiDeviceDropdown.Items.Clear();

        var midiDeviceNames = midiManager.GetMidiDeviceNames();
        for (int i = 0; i < midiDeviceNames.Count; i++)
        {
            midiDeviceDropdown.Items.Add(new KeyValuePair<int, string>(i, midiDeviceNames[i]));
        }

        midiDeviceDropdown.DisplayMember = "Value";
        midiDeviceDropdown.ValueMember = "Key";

        if (midiDeviceDropdown.Items.Count > 0)
        {
            midiDeviceDropdown.SelectedIndex = 0; // 첫 번째 장치 기본 선택
        }
    }


    private void SelectMidiDeviceButton_Click(object sender, EventArgs e)
    {
        if (midiDeviceDropdown.SelectedItem is KeyValuePair<int, string> selectedDevice)
        {
            int deviceIndex = selectedDevice.Key;
            string deviceName = selectedDevice.Value;

            midiManager.SetActiveMidiDevice(deviceIndex);
            MessageBox.Show($"Active MIDI Device set to: {deviceName} (Index: {deviceIndex})");
        }
        else
        {
            MessageBox.Show("No MIDI device selected!");
        }
    }

    
}
